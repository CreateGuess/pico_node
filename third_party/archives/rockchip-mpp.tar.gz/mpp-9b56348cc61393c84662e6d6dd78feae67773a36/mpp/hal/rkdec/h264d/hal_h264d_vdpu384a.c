/* SPDX-License-Identifier: Apache-2.0 OR MIT */
/*
 * Copyright (c) 2024 Rockchip Electronics Co., Ltd.
 */

#define MODULE_TAG "hal_h264d_vdpu384a"

#include <string.h>

#include "mpp_env.h"
#include "mpp_mem.h"
#include "mpp_common.h"
#include "mpp_bitput.h"
#include "mpp_buffer_impl.h"

#include "hal_h264d_global.h"
#include "hal_h264d_vdpu384a.h"
#include "mpp_dec_cb_param.h"
#include "vdpu_com.h"
#include "vdpu38x_com.h"
#include "vdpu384a_com.h"
#include "hal_h264d_ctx.h"
#include "hal_h264d_com.h"

/* Number registers for the decoder */
#define DEC_VDPU384A_REGISTERS               276

#define VDPU384A_SPSPPS_SIZE                 (MPP_ALIGN(2266 + 64, 128) / 8) /* byte, 2266 bit + Reserve 64 */
#define VDPU384A_SCALING_LIST_SIZE           (6*16+2*64 + 128)   /* bytes */
#define VDPU384A_ERROR_INFO_SIZE             (256*144*4)         /* bytes */

#define VDPU384A_ERROR_INFO_ALIGNED_SIZE     (0)
#define VDPU384A_SPSPPS_ALIGNED_SIZE         (MPP_ALIGN(VDPU384A_SPSPPS_SIZE, SZ_4K))
#define VDPU384A_SCALING_LIST_ALIGNED_SIZE   (MPP_ALIGN(VDPU384A_SCALING_LIST_SIZE, SZ_4K))
#define VDPU384A_STREAM_INFO_SET_SIZE        (VDPU384A_SPSPPS_ALIGNED_SIZE + \
                                             VDPU384A_SCALING_LIST_ALIGNED_SIZE)

#define VDPU384A_ERROR_INFO_OFFSET           (0)
#define VDPU384A_STREAM_INFO_OFFSET_BASE     (VDPU384A_ERROR_INFO_OFFSET + VDPU384A_ERROR_INFO_ALIGNED_SIZE)
#define VDPU384A_SPSPPS_OFFSET(pos)          (VDPU384A_STREAM_INFO_OFFSET_BASE + (VDPU384A_STREAM_INFO_SET_SIZE * pos))
#define VDPU384A_SCALING_LIST_OFFSET(pos)    (VDPU384A_SPSPPS_OFFSET(pos) + VDPU384A_SPSPPS_ALIGNED_SIZE)
#define VDPU384A_INFO_BUFFER_SIZE(cnt)       (VDPU384A_STREAM_INFO_OFFSET_BASE + (VDPU384A_STREAM_INFO_SET_SIZE * cnt))

static MPP_RET set_registers(H264dHalCtx_t *p_hal, Vdpu384aRegSet *regs, HalTaskInfo *task)
{
    DXVA_PicParams_H264_MVC *pp = p_hal->pp;
    HalBuf *mv_buf = NULL;
    HalBuf *origin_buf = NULL;
    Vdpu3xxH264dRegCtx *ctx = (Vdpu3xxH264dRegCtx *)p_hal->reg_ctx;
    MppHalCfg *cfg = p_hal->cfg;
    MppFrame mframe = NULL;

    // memset(regs, 0, sizeof(Vdpu384aRegSet));
    regs->comm_paras.reg66_stream_len = p_hal->strm_len;

    //!< caculate the yuv_frame_size
    mpp_buf_slot_get_prop(cfg->frame_slots, pp->CurrPic.Index7Bits, SLOT_FRAME_PTR, &mframe);
    if (vdpu384a_setup_cur_stride_info(mframe, regs, 1)) {
        mpp_err_f("failed to setup stride info for current frame\n");
        return MPP_NOK;
    }

    //!< set current
    {
        MppBuffer mbuffer = NULL;
        RK_S32 fd = -1;

        mpp_buf_slot_get_prop(cfg->frame_slots, pp->CurrPic.Index7Bits, SLOT_BUFFER, &mbuffer);
        fd = mpp_buffer_get_fd(mbuffer);
        /* output rkfbc64 */
        // regs->comm_addrs.reg168_dpb_decout_base = fd;
        /* output raster/tile4x4 */
        regs->comm_addrs.reg135_pp_m_decout_base = fd;
        regs->comm_addrs.reg192_dpb_payload64x4_st_cur_base = fd;

        //colmv_cur_base
        mv_buf = hal_bufs_get_buf(p_hal->cmv_bufs, pp->CurrPic.Index7Bits);
        regs->comm_addrs.reg216_colmv_cur_base = mpp_buffer_get_fd(mv_buf->buf[0]);
        regs->comm_addrs.reg169_error_ref_base = fd;
    }
    //!< set reference
    {
        RK_S32 i = 0;
        RK_S32 fd = -1;
        RK_S32 ref_index = -1;
        RK_S32 near_index = -1;
        MppBuffer mbuffer = NULL;
        RK_U32 min_frame_num  = 0;

        for (i = 0; i < 15; i++) {
            if (pp->RefFrameList[i].bPicEntry != 0xff) {
                ref_index = pp->RefFrameList[i].Index7Bits;
                near_index = pp->RefFrameList[i].Index7Bits;
            } else {
                ref_index = (near_index < 0) ? pp->CurrPic.Index7Bits : near_index;
            }
            /* mark 3 to differ from current frame */
            mpp_buf_slot_get_prop(cfg->frame_slots, ref_index, SLOT_BUFFER, &mbuffer);
            mpp_buf_slot_get_prop(cfg->frame_slots, ref_index, SLOT_FRAME_PTR, &mframe);
            if (ctx->origin_bufs && mpp_frame_get_thumbnail_en(mframe) == MPP_FRAME_THUMBNAIL_ONLY) {
                origin_buf = hal_bufs_get_buf(ctx->origin_bufs, ref_index);
                mbuffer = origin_buf->buf[0];
            }

            if (pp->FrameNumList[i] < pp->frame_num &&
                pp->FrameNumList[i] > min_frame_num &&
                (!mpp_frame_get_errinfo(mframe))) {
                min_frame_num = pp->FrameNumList[i];
                regs->comm_addrs.reg169_error_ref_base = mpp_buffer_get_fd(mbuffer);
            }

            fd = mpp_buffer_get_fd(mbuffer);
            regs->comm_addrs.reg170_185_ref_base[i] = fd;
            regs->comm_addrs.reg195_210_payload_st_ref_base[i] = fd;
            mv_buf = hal_bufs_get_buf(p_hal->cmv_bufs, ref_index);
            regs->comm_addrs.reg217_232_colmv_ref_base[i] = mpp_buffer_get_fd(mv_buf->buf[0]);
        }

        if (pp->RefFrameList[15].bPicEntry != 0xff) {
            ref_index = pp->RefFrameList[15].Index7Bits;
        } else {
            ref_index = (near_index < 0) ? pp->CurrPic.Index7Bits : near_index;
        }

        mpp_buf_slot_get_prop(cfg->frame_slots, ref_index, SLOT_BUFFER, &mbuffer);
        fd = mpp_buffer_get_fd(mbuffer);
        if (mpp_frame_get_thumbnail_en(mframe) == 2) {
            origin_buf = hal_bufs_get_buf(ctx->origin_bufs, ref_index);
            fd = mpp_buffer_get_fd(origin_buf->buf[0]);
        }
        regs->comm_addrs.reg170_185_ref_base[15] = fd;
        regs->comm_addrs.reg195_210_payload_st_ref_base[15] = fd;
        mv_buf = hal_bufs_get_buf(p_hal->cmv_bufs, ref_index);
        regs->comm_addrs.reg217_232_colmv_ref_base[15] = mpp_buffer_get_fd(mv_buf->buf[0]);
    }
    {
        MppBuffer mbuffer = NULL;

        mpp_buf_slot_get_prop(cfg->packet_slots, task->dec.input, SLOT_BUFFER, &mbuffer);
        regs->comm_addrs.reg128_strm_base = mpp_buffer_get_fd(mbuffer);
        regs->comm_addrs.reg129_stream_buf_st_base = mpp_buffer_get_fd(mbuffer);
        regs->comm_addrs.reg130_stream_buf_end_base = mpp_buffer_get_fd(mbuffer);
        mpp_dev_set_reg_offset(cfg->dev, 130, mpp_buffer_get_size(mbuffer));
        // regs->comm_paras.reg65_strm_start_bit = 2 * 8;
        hal_dbg_dumpf_buf(p_hal->dbg_ctx, "stream_in.dat", mbuffer, 0,
                          p_hal->strm_len, 128, "w+");
    }

    {
        //scale down config
        MppFrame mframe = NULL;
        MppBuffer mbuffer = NULL;
        RK_S32 fd = -1;
        MppFrameThumbnailMode thumbnail_mode;

        mpp_buf_slot_get_prop(cfg->frame_slots, pp->CurrPic.Index7Bits, SLOT_BUFFER, &mbuffer);
        mpp_buf_slot_get_prop(cfg->frame_slots, pp->CurrPic.Index7Bits,
                              SLOT_FRAME_PTR, &mframe);
        fd = mpp_buffer_get_fd(mbuffer);
        thumbnail_mode = mpp_frame_get_thumbnail_en(mframe);
        switch (thumbnail_mode) {
        case MPP_FRAME_THUMBNAIL_ONLY:
            regs->comm_addrs.reg133_scale_down_base = fd;
            origin_buf = hal_bufs_get_buf(ctx->origin_bufs, pp->CurrPic.Index7Bits);
            fd = mpp_buffer_get_fd(origin_buf->buf[0]);
            /* output rkfbc64 */
            // regs->comm_addrs.reg168_dpb_decout_base = fd;
            /* output raster/tile4x4 */
            regs->comm_addrs.reg135_pp_m_decout_base = fd;
            regs->comm_addrs.reg192_dpb_payload64x4_st_cur_base = fd;
            regs->comm_addrs.reg169_error_ref_base = fd;
            vdpu384a_setup_down_scale(mframe, cfg->dev, &regs->ctrl_regs, (void*)&regs->comm_paras);
            break;
        case MPP_FRAME_THUMBNAIL_MIXED:
            regs->comm_addrs.reg133_scale_down_base = fd;
            vdpu384a_setup_down_scale(mframe, cfg->dev, &regs->ctrl_regs, (void*)&regs->comm_paras);
            break;
        case MPP_FRAME_THUMBNAIL_NONE:
        default:
            regs->ctrl_regs.reg9.scale_down_en = 0;
            break;
        }
    }

    return MPP_OK;
}

MPP_RET vdpu384a_h264d_init(void *hal, MppHalCfg *cfg)
{
    MPP_RET ret = MPP_ERR_UNKNOW;
    H264dHalCtx_t *p_hal = (H264dHalCtx_t *)hal;

    mpp_env_get_u32("hal_h264d_debug", &hal_h264d_debug, 0);

    INP_CHECK(ret, NULL == p_hal);

    p_hal->cfg = cfg;
    cfg->support_fast_mode = 1;
    p_hal->fast_mode = cfg->cfg->base.fast_parse && cfg->support_fast_mode;

    MEM_CHECK(ret, p_hal->reg_ctx = mpp_calloc_size(void, sizeof(Vdpu3xxH264dRegCtx)));
    Vdpu3xxH264dRegCtx *reg_ctx = (Vdpu3xxH264dRegCtx *)p_hal->reg_ctx;
    RK_U32 max_cnt = (p_hal->fast_mode != 0) ? VDPU_FAST_REG_SET_CNT : 1;
    RK_U32 i = 0;

    //!< malloc buffers
    reg_ctx->spspps = mpp_calloc(RK_U8, VDPU384A_SPSPPS_SIZE);
    reg_ctx->sclst = mpp_calloc(RK_U8, VDPU384A_SCALING_LIST_SIZE);
    FUN_CHECK(ret = mpp_buffer_get(cfg->buf_group, &reg_ctx->bufs,
                                   VDPU384A_INFO_BUFFER_SIZE(max_cnt)));
    reg_ctx->bufs_fd = mpp_buffer_get_fd(reg_ctx->bufs);
    reg_ctx->bufs_ptr = mpp_buffer_get_ptr(reg_ctx->bufs);
    reg_ctx->offset_errinfo = VDPU384A_ERROR_INFO_OFFSET;
    for (i = 0; i < max_cnt; i++) {
        reg_ctx->reg_buf[i].regs = mpp_calloc(Vdpu384aRegSet, 1);
        vdpu384a_init_ctrl_regs(reg_ctx->reg_buf[i].regs, MPP_VIDEO_CodingAVC);
        reg_ctx->offset_spspps[i] = VDPU384A_SPSPPS_OFFSET(i);
        reg_ctx->offset_sclst[i] = VDPU384A_SCALING_LIST_OFFSET(i);
    }

    mpp_buffer_attach_dev(reg_ctx->bufs, cfg->dev);

    if (!p_hal->fast_mode) {
        reg_ctx->regs = reg_ctx->reg_buf[0].regs;
        reg_ctx->spspps_offset = reg_ctx->offset_spspps[0];
        reg_ctx->sclst_offset = reg_ctx->offset_sclst[0];
    }

    mpp_slots_set_prop(cfg->frame_slots, SLOTS_HOR_ALIGN, mpp_align_128_odd_plus_64);
    mpp_slots_set_prop(cfg->frame_slots, SLOTS_VER_ALIGN, mpp_align_16);
    mpp_slots_set_prop(cfg->frame_slots, SLOTS_LEN_ALIGN, mpp_align_wxh2yuv420);

    if (cfg->hal_fbc_adj_cfg) {
        cfg->hal_fbc_adj_cfg->func = vdpu_afbc_align_calc;
        cfg->hal_fbc_adj_cfg->expand = 16;
    }

    vdpu38x_rcb_calc_init((Vdpu38xRcbCtx **)&reg_ctx->rcb_ctx);
    hal_dbg_init(&p_hal->dbg_ctx, "hal_h264d");
    if (p_hal->fast_mode && p_hal->dbg_ctx) {
        mpp_log("fast mode enabled, hal_dbg will be disabled");
        hal_dbg_deinit(&p_hal->dbg_ctx);
    }

__RETURN:
    return MPP_OK;
__FAILED:
    vdpu3xx_h264d_deinit(hal);

    return ret;
}

static MPP_RET vdpu384a_h264d_rcb_calc(void *context, RK_U32 *total_size)
{
    Vdpu38xRcbCtx *ctx = (Vdpu38xRcbCtx *)context;
    RK_FLOAT cur_bit_size = 0;
    RK_U32 cur_uv_para = 0;
    RK_U32 bit_depth = ctx->bit_depth;
    RK_U32 in_tl_row = 0;
    RK_U32 on_tl_row = 0;
    RK_U32 on_tl_col = 0;
    Vdpu38xFmt rcb_fmt;

    /* vdpu383/vdpu384a/vdpu384b fix 10bit */
    bit_depth = 10;

    vdpu38x_rcb_get_len(ctx, VDPU38X_RCB_IN_TILE_ROW, &in_tl_row);
    vdpu38x_rcb_get_len(ctx, VDPU38X_RCB_ON_TILE_ROW, &on_tl_row);
    vdpu38x_rcb_get_len(ctx, VDPU38X_RCB_ON_TILE_COL, &on_tl_col);
    rcb_fmt = vdpu38x_rcb_get_fmt(ctx);

    /* RCB_STRMD_IN_ROW */
    cur_bit_size = 0;
    vdpu38x_rcb_reg_info_update(ctx, RCB_STRMD_IN_ROW, 140, cur_bit_size);

    /* RCB_STRMD_ON_ROW */
    cur_bit_size = 0;
    /*
     * For all spec, the hardware connects all in-tile rows of strmd to the on-tile.
     * Therefore, only strmd on-tile needs to be configured, and there is no need to
     * configure strmd in-tile.
     *
     * Versions with issues: rk3576(383), swan1126b (384a), shark/robin (384b).
     */
    if (ctx->pic_w > 4096)
        cur_bit_size = MPP_DIVUP(16, in_tl_row) * 158 * (1 + ctx->mbaff_flag);
    vdpu38x_rcb_reg_info_update(ctx, RCB_STRMD_ON_ROW, 142, cur_bit_size);

    /* RCB_INTER_IN_ROW */
    cur_bit_size = 0;
    cur_bit_size = MPP_DIVUP(4, in_tl_row) * 92 * (1 + ctx->mbaff_flag);
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTER_IN_ROW, 144, cur_bit_size);

    /* RCB_INTER_ON_ROW */
    cur_bit_size = 0;
    cur_bit_size = MPP_DIVUP(4, on_tl_row) * 92 * (1 + ctx->mbaff_flag);
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTER_ON_ROW, 146, cur_bit_size);

    /* RCB_INTRA_IN_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_intra_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(512, (in_tl_row * (bit_depth + 2)
                                     * (1 + ctx->mbaff_flag) * cur_uv_para));
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTRA_IN_ROW, 148, cur_bit_size);

    /* RCB_INTRA_ON_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_intra_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(512, (on_tl_row * (bit_depth + 2)
                                     * (1 + ctx->mbaff_flag) * cur_uv_para));
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTRA_ON_ROW, 150, cur_bit_size);

    /* RCB_FLTD_IN_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_filter_row_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(16, in_tl_row) * (1.2 * bit_depth + 0.5)
                   * (( 6 + 3 * cur_uv_para) * (1 + ctx->mbaff_flag)
                      + 2 * cur_uv_para + 1.5);
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_IN_ROW, 152, cur_bit_size);

    /* RCB_FLTD_PROT_IN_ROW */
    cur_bit_size = 0;
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_PROT_IN_ROW, 154, cur_bit_size);

    /* RCB_FLTD_ON_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_filter_row_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(16, on_tl_row) * (1.2 * bit_depth + 0.5)
                   * (( 6 + 3 * cur_uv_para) * (1 + ctx->mbaff_flag)
                      + 2 * cur_uv_para + 1.5);
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_ON_ROW, 156, cur_bit_size);

    /* RCB_FLTD_ON_COL */
    cur_bit_size = 0;
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_ON_COL, 158, cur_bit_size);

    /* RCB_FLTD_UPSC_ON_COL */
    cur_bit_size = 0;
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_UPSC_ON_COL, 160, cur_bit_size);

    *total_size = vdpu38x_rcb_get_total_size(ctx);

    return MPP_OK;
}

MPP_RET vdpu384a_h264d_gen_regs(void *hal, HalTaskInfo *task)
{
    MPP_RET ret = MPP_ERR_UNKNOW;
    H264dHalCtx_t *p_hal = (H264dHalCtx_t *)hal;
    Vdpu3xxH264dRegCtx *ctx = (Vdpu3xxH264dRegCtx *)p_hal->reg_ctx;
    Vdpu384aRegSet *regs = ctx->regs;
    MppHalCfg *cfg = p_hal->cfg;
    RK_S32 width, height, mv_size;
    MppFrame mframe;

    INP_CHECK(ret, NULL == p_hal);

    if (task->dec.flags.parse_err ||
        (task->dec.flags.ref_err && !cfg->cfg->base.disable_error)) {
        goto __RETURN;
    }
    hal_h264d_explain_input_buffer(hal, &task->dec);

    width = MPP_ALIGN((p_hal->pp->wFrameWidthInMbsMinus1 + 1) << 4, 64);
    height = MPP_ALIGN((p_hal->pp->wFrameHeightInMbsMinus1 + 1) << 4, 64);
    mv_size = MPP_ALIGN(width, 64) * MPP_ALIGN(height, 16); // 16 byte unit

    /* if is field mode is enabled enlarge colmv buffer and disable colmv compression */
    if (!p_hal->pp->frame_mbs_only_flag)
        mv_size *= 2;

    if (p_hal->cmv_bufs == NULL || p_hal->mv_size < mv_size) {
        size_t size = mv_size;

        if (p_hal->cmv_bufs) {
            hal_bufs_deinit(p_hal->cmv_bufs);
            p_hal->cmv_bufs = NULL;
        }

        hal_bufs_init(&p_hal->cmv_bufs);
        if (p_hal->cmv_bufs == NULL) {
            mpp_err_f("colmv bufs init fail");
            goto __RETURN;
        }
        p_hal->mv_size = mv_size;
        p_hal->mv_count = mpp_buf_slot_get_count(cfg->frame_slots);
        hal_bufs_setup(p_hal->cmv_bufs, p_hal->mv_count, 1, &size);
    }

    mpp_buf_slot_get_prop(cfg->frame_slots, p_hal->pp->CurrPic.Index7Bits, SLOT_FRAME_PTR, &mframe);
    if (mpp_frame_get_thumbnail_en(mframe) == MPP_FRAME_THUMBNAIL_ONLY &&
        ctx->origin_bufs == NULL) {
        vdpu38x_setup_scale_origin_bufs(mframe, &ctx->origin_bufs,
                                        mpp_buf_slot_get_count(cfg->frame_slots));
    }

    if (p_hal->fast_mode) {
        RK_U32 i = 0;
        for (i = 0; i <  MPP_ARRAY_ELEMS(ctx->reg_buf); i++) {
            if (!ctx->reg_buf[i].valid) {
                task->dec.reg_index = i;
                regs = ctx->reg_buf[i].regs;

                ctx->spspps_offset = ctx->offset_spspps[i];
                ctx->sclst_offset = ctx->offset_sclst[i];
                ctx->reg_buf[i].valid = 1;
                break;
            }
        }
    } else {
        task->dec.reg_index = 0;
    }

    hal_dbg_setup(p_hal->dbg_ctx, NULL);

    vdpu38x_h264d_dbg_ref_frames(p_hal);

    vdpu38x_h264d_prepare_spspps(p_hal, (RK_U64 *)ctx->spspps, VDPU384A_SPSPPS_SIZE / 8);
    vdpu38x_h264d_prepare_scanlist(p_hal, ctx->sclst, VDPU384A_SCALING_LIST_SIZE);
    set_registers(p_hal, regs, task);

    //!< copy spspps datas
    memcpy((char *)ctx->bufs_ptr + ctx->spspps_offset, (char *)ctx->spspps, VDPU384A_SPSPPS_SIZE);

    regs->comm_addrs.reg131_gbl_base = ctx->bufs_fd;
    regs->comm_paras.reg67_global_len = VDPU384A_SPSPPS_SIZE / 16; // 128 bit as unit
    mpp_dev_set_reg_offset(cfg->dev, 131, ctx->spspps_offset);

    if (p_hal->pp->scaleing_list_enable_flag) {
        memcpy((char *)ctx->bufs_ptr + ctx->sclst_offset, (void *)ctx->sclst, VDPU384A_SCALING_LIST_SIZE);
        regs->comm_addrs.reg132_scanlist_addr = ctx->bufs_fd;
        mpp_dev_set_reg_offset(cfg->dev, 132, ctx->sclst_offset);
    } else {
        regs->comm_addrs.reg132_scanlist_addr = 0;
    }

    vdpu38x_h264d_rcb_setup(p_hal, task, &regs->comm_addrs.rcb_regs,
                            vdpu384a_h264d_rcb_calc);
    vdpu384a_setup_statistic(&regs->ctrl_regs);
    mpp_buffer_sync_end(ctx->bufs);

__RETURN:
    return ret = MPP_OK;
}

MPP_RET vdpu384a_h264d_start(void *hal, HalTaskInfo *task)
{
    MPP_RET ret = MPP_ERR_UNKNOW;
    H264dHalCtx_t *p_hal = (H264dHalCtx_t *)hal;
    INP_CHECK(ret, NULL == p_hal);

    if (task->dec.flags.parse_err ||
        (task->dec.flags.ref_err && !p_hal->cfg->cfg->base.disable_error)) {
        goto __RETURN;
    }

    Vdpu3xxH264dRegCtx *reg_ctx = (Vdpu3xxH264dRegCtx *)p_hal->reg_ctx;
    Vdpu384aRegSet *regs = (p_hal->fast_mode != 0) ?
                           reg_ctx->reg_buf[task->dec.reg_index].regs :
                           reg_ctx->regs;
    MppDev dev = p_hal->cfg->dev;

    do {
        MppDevRegWrCfg wr_cfg;
        MppDevRegRdCfg rd_cfg;

        wr_cfg.reg = &regs->ctrl_regs;
        wr_cfg.size = sizeof(regs->ctrl_regs);
        wr_cfg.offset = VDPU38X_OFF_CTRL_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_WR, &wr_cfg);
        if (ret) {
            mpp_err_f("set register write failed %d\n", ret);
            break;
        }

        wr_cfg.reg = &regs->comm_paras;
        wr_cfg.size = sizeof(regs->comm_paras);
        wr_cfg.offset = VDPU38X_OFF_CODEC_PARAS_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_WR, &wr_cfg);
        if (ret) {
            mpp_err_f("set register write failed %d\n", ret);
            break;
        }

        wr_cfg.reg = &regs->comm_addrs;
        wr_cfg.size = sizeof(regs->comm_addrs);
        wr_cfg.offset = VDPU38X_OFF_COMMON_ADDR_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_WR, &wr_cfg);
        if (ret) {
            mpp_err_f("set register write failed %d\n", ret);
            break;
        }

        rd_cfg.reg = &regs->ctrl_regs.reg15;
        rd_cfg.size = sizeof(regs->ctrl_regs.reg15);
        rd_cfg.offset = VDPU38X_OFF_INTERRUPT_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);
        if (ret) {
            mpp_err_f("set register read failed %d\n", ret);
            break;
        }

        vdpu384a_dump_sw_regs(regs, p_hal->dbg_ctx);

        ret = MPP_OK;
        if (hal_dbg_flag_en(p_hal->dbg_ctx, HAL_DBG_GET_REG)) {
            rd_cfg.reg = &regs->reg_version;
            rd_cfg.size = sizeof(regs->reg_version);
            rd_cfg.offset = 0;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->ctrl_regs;
            rd_cfg.size = sizeof(regs->ctrl_regs);
            rd_cfg.offset = VDPU38X_OFF_CTRL_REGS;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->comm_paras;
            rd_cfg.size = sizeof(regs->comm_paras);
            rd_cfg.offset = VDPU38X_OFF_CODEC_PARAS_REGS;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->comm_addrs;
            rd_cfg.size = sizeof(regs->comm_addrs);
            rd_cfg.offset = VDPU38X_OFF_COMMON_ADDR_REGS;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->statistic_regs;
            rd_cfg.size = sizeof(regs->statistic_regs);
            rd_cfg.offset = VDPU38X_OFF_COM_STATISTIC_REGS_VDPU384A;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);
        } else if (hal_dbg_flag_en(p_hal->dbg_ctx, HAL_DBG_STA_CHK)) {
            rd_cfg.reg = &regs->statistic_regs;
            rd_cfg.size = sizeof(regs->statistic_regs);
            rd_cfg.offset = VDPU38X_OFF_COM_STATISTIC_REGS_VDPU384A;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);
        }
        if (ret) {
            mpp_err_f("set register read (debug) failed %d\n", ret);
        }

        /* rcb info for sram */
        vdpu38x_rcb_set_info(reg_ctx->rcb_ctx, dev);

        /* send request to hardware */
        ret = mpp_dev_ioctl(dev, MPP_DEV_CMD_SEND, NULL);
        if (ret) {
            mpp_err_f("send cmd failed %d\n", ret);
            break;
        }
    } while (0);

__RETURN:
    return ret = MPP_OK;
}

MPP_RET vdpu384a_h264d_wait(void *hal, HalTaskInfo *task)
{
    MPP_RET ret = MPP_ERR_UNKNOW;
    H264dHalCtx_t *p_hal = (H264dHalCtx_t *)hal;

    INP_CHECK(ret, NULL == p_hal);
    Vdpu3xxH264dRegCtx *reg_ctx = (Vdpu3xxH264dRegCtx *)p_hal->reg_ctx;
    Vdpu384aRegSet *p_regs = (p_hal->fast_mode != 0) ?
                             reg_ctx->reg_buf[task->dec.reg_index].regs :
                             reg_ctx->regs;

    if (task->dec.flags.parse_err ||
        (task->dec.flags.ref_err && !p_hal->cfg->cfg->base.disable_error)) {
        goto __SKIP_HARD;
    }

    ret = mpp_dev_ioctl(p_hal->cfg->dev, MPP_DEV_CMD_POLL, NULL);
    if (ret)
        mpp_err_f("poll cmd failed %d\n", ret);

    if (hal_dbg_flag_en(p_hal->dbg_ctx, HAL_DBG_STA_CHK) &&
        (p_regs->statistic_regs.reg292.rcb_rd_sum_chk !=
         p_regs->statistic_regs.reg292.rcb_wr_sum_chk)) {
        mpp_loge("rcb rd sum %d wr sum %d\n",
                 p_regs->statistic_regs.reg292.rcb_rd_sum_chk,
                 p_regs->statistic_regs.reg292.rcb_wr_sum_chk);
    }

    if (hal_dbg_flag_en(p_hal->dbg_ctx, HAL_DBG_GET_REG))
        vdpu384a_dump_hw_regs(p_regs, p_hal->dbg_ctx);

__SKIP_HARD:
    if (p_hal->cfg->dec_cb) {
        DecCbHalDone param;

        param.task = (void *)&task->dec;
        param.regs = (RK_U32 *)p_regs;

        if ((!p_regs->ctrl_regs.reg15.rkvdec_frame_rdy_sta) ||
            p_regs->ctrl_regs.reg15.rkvdec_strm_error_sta ||
            p_regs->ctrl_regs.reg15.rkvdec_core_timeout_sta ||
            p_regs->ctrl_regs.reg15.rkvdec_ip_timeout_sta ||
            p_regs->ctrl_regs.reg15.rkvdec_bus_error_sta ||
            p_regs->ctrl_regs.reg15.rkvdec_buffer_empty_sta ||
            p_regs->ctrl_regs.reg15.rkvdec_colmv_ref_error_sta)
            param.hard_err = 1;
        else
            param.hard_err = 0;

        mpp_callback(p_hal->cfg->dec_cb, &param);
    }
    memset(&p_regs->ctrl_regs.reg19, 0, sizeof(RK_U32));
    if (p_hal->fast_mode) {
        reg_ctx->reg_buf[task->dec.reg_index].valid = 0;
    }

__RETURN:
    hal_dbg_finish(p_hal->dbg_ctx);

    return ret = MPP_OK;
}

const MppHalApi hal_h264d_vdpu384a = {
    .name     = "h264d_vdpu384a",
    .type     = MPP_CTX_DEC,
    .coding   = MPP_VIDEO_CodingAVC,
    .ctx_size = sizeof(H264dHalCtx_t),
    .flag     = 0,
    .init     = vdpu384a_h264d_init,
    .deinit   = vdpu3xx_h264d_deinit,
    .reg_gen  = vdpu384a_h264d_gen_regs,
    .start    = vdpu384a_h264d_start,
    .wait     = vdpu384a_h264d_wait,
    .reset    = vdpu_h264d_reset,
    .flush    = vdpu_h264d_flush,
    .control  = vdpu38x_h264d_control,
    .client   = VPU_CLIENT_RKVDEC,
    .soc_type = {
        ROCKCHIP_SOC_RV1126B,
        ROCKCHIP_SOC_BUTT
    },
};

MPP_DEC_HAL_API_REGISTER(hal_h264d_vdpu384a)
