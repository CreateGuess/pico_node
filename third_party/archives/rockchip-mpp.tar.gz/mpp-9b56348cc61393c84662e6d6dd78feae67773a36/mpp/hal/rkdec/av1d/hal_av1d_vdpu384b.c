/* SPDX-License-Identifier: Apache-2.0 OR MIT */
/*
 * Copyright (c) 2025 Rockchip Electronics Co., Ltd.
 */

#define MODULE_TAG "hal_av1d_vdpu384b"

#include "mpp_buffer_impl.h"
#include "mpp_env.h"

#include "hal_av1d_com.h"
#include "hal_av1d_ctx.h"
#include "vdpu38x_com.h"

#define VDPU384B_UNCMPS_HEADER_SIZE          (MPP_ALIGN(5160 + 64, 128) / 8) // byte, 5160 bit + Reserve 64
#define VDPU384B_UNCMPS_HEADER_OFFSET_BASE   (0)
#define VDPU384B_INFO_ELEM_SIZE              (VDPU384B_UNCMPS_HEADER_SIZE)
#define VDPU384B_UNCMPS_HEADER_OFFSET(idx)   (VDPU384B_INFO_ELEM_SIZE * idx + VDPU384B_UNCMPS_HEADER_OFFSET_BASE)
#define VDPU384B_INFO_BUF_SIZE(cnt)          (VDPU384B_INFO_ELEM_SIZE * cnt)
#define VDPU384B_DEF_CDF_UPDATE_ARRAY_SIZE   (20)

static struct {
    RK_U32 org_data_off;  // char unit
    RK_U32 new_data_sz;   // char unit
    RK_U32 data[16];
} vdpu384b_def_prob_update_info[VDPU384B_DEF_CDF_UPDATE_ARRAY_SIZE] = {
    {
        .org_data_off = 314 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0xc173a0d7, 0x76e1e02e, 0xb019c8a6, 0x48523960,
            0xfcf54494, 0x58c607f1, 0x4c5b184f, 0x80000001,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 330 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0xc0a5182c, 0x75d18016, 0xb40d6060, 0xf137393d,
            0xa9ef068a, 0xea22d40b, 0xf22e827e, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 346 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x01069b27, 0x96e8c00c, 0x4c0dd857, 0x7a22c525,
            0x16a81083, 0xaa70ad26, 0x43795d65, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 362 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 378 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 491 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x41b61d2e, 0xe74de045, 0xf02740d6, 0x2d595f68,
            0x5936ad18, 0x6ee6bc13, 0x4bb32457, 0x80000001,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 507 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x808a1940, 0xc608e011, 0x380bf856, 0x582b552a,
            0x432e7908, 0xf762f86b, 0xf76a937e, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 523 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0xc0649afa, 0xe5d8c008, 0x9406482c, 0x0210bef2,
            0x05260e82, 0xa3b0a1c5, 0x3c293fe5, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 539 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 555 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 668 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x01a9961d, 0x372f0054, 0xa030e8f2, 0x74588d60,
            0x63f6e617, 0x6c067a53, 0x3ca32777, 0x80000001,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 684 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0xc0869232, 0x75774018, 0xa4178872, 0xc93e1d38,
            0xa1f3378f, 0x1bf4bfcf, 0xf8feb4df, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 700 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x803a117d, 0x564ee005, 0x38062829, 0xe22e7d18,
            0xefabdf0d, 0x62920009, 0x92a1e0c6, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 716 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 732 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 845 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x015292b2, 0x46b3602e, 0x8c18e0b5, 0xe4520d5d,
            0x9ff44d12, 0x90058092, 0x14032807, 0x80000001,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 861 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x80fb8f5a, 0x26616026, 0xc81a80a0, 0xe350ed50,
            0x27f59c12, 0xc474c0d2, 0xe9766d7e, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 877 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0xc0f59478, 0xd7b82015, 0x28150063, 0xc647af5c,
            0x00300012, 0xd174aab0, 0xba31d17d, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 893 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
    {
        .org_data_off = 909 * 8 * 4,
        .new_data_sz = 64,
        .data = {
            0x20006000, 0x0c000800, 0x01000400, 0x00800180,
            0x00300020, 0x00040010, 0x80020006, 0x80000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
            0x00000000, 0x00000000, 0x00000000, 0x00000000,
        },
    },
};

static MPP_RET hal_av1d_alloc_res(void *hal)
{
    Av1dHalCtx *p_hal = (Av1dHalCtx *)hal;
    RK_U32 max_cnt = (p_hal->fast_mode != 0) ? VDPU_FAST_REG_SET_CNT : 1;
    void *cdf_ptr;
    Vdpu38xAv1dRegCtx *reg_ctx = NULL;
    RK_U32 i = 0;
    MPP_RET ret = MPP_OK;

    INP_CHECK(ret, NULL == p_hal);

    MEM_CHECK(ret, p_hal->reg_ctx = mpp_calloc_size(void, sizeof(Vdpu38xAv1dRegCtx) +
                                                    VDPU384B_UNCMPS_HEADER_SIZE));
    reg_ctx = (Vdpu38xAv1dRegCtx *)p_hal->reg_ctx;

    //!< malloc buffers
    BUF_CHECK(ret, mpp_buffer_get(p_hal->cfg->buf_group, &reg_ctx->bufs, VDPU384B_INFO_BUF_SIZE(max_cnt)));
    mpp_buffer_attach_dev(reg_ctx->bufs, p_hal->cfg->dev);
    reg_ctx->bufs_fd = mpp_buffer_get_fd(reg_ctx->bufs);
    reg_ctx->bufs_ptr = mpp_buffer_get_ptr(reg_ctx->bufs);


    for (i = 0; i < max_cnt; i++) {
        reg_ctx->reg_buf[i].regs = mpp_calloc(Vdpu38xRegSet, 1);
        memset(reg_ctx->reg_buf[i].regs, 0, sizeof(Vdpu38xRegSet));
        reg_ctx->uncmps_offset[i] = VDPU384B_UNCMPS_HEADER_OFFSET(i);
    }

    if (!p_hal->fast_mode) {
        reg_ctx->regs = reg_ctx->reg_buf[0].regs;
        reg_ctx->offset_uncomps = reg_ctx->uncmps_offset[0];
    }

    BUF_CHECK(ret, mpp_buffer_get(p_hal->cfg->buf_group, &reg_ctx->cdf_rd_def_base, MPP_ALIGN(sizeof(g_av1d_default_prob), 2048)));
    mpp_buffer_attach_dev(reg_ctx->cdf_rd_def_base, p_hal->cfg->dev);
    cdf_ptr = mpp_buffer_get_ptr(reg_ctx->cdf_rd_def_base);
    memcpy(cdf_ptr, g_av1d_default_prob, sizeof(g_av1d_default_prob));
    /* update vdpu384b def cdf */
    {
        RK_U8 *src, *dst;

        for (i = 0; i < VDPU384B_DEF_CDF_UPDATE_ARRAY_SIZE; i++) {
            src = (RK_U8 *)vdpu384b_def_prob_update_info[i].data;
            dst = (RK_U8 *)cdf_ptr;
            dst += vdpu384b_def_prob_update_info[i].org_data_off;
            memcpy(dst, src, vdpu384b_def_prob_update_info[i].new_data_sz);
        }
    }
    mpp_buffer_sync_end(reg_ctx->cdf_rd_def_base);

__RETURN:
    return ret;
__FAILED:
    return ret;
}

MPP_RET vdpu384b_av1d_init(void *hal, MppHalCfg *cfg)
{
    Av1dHalCtx *p_hal = (Av1dHalCtx *)hal;
    Vdpu38xAv1dRegCtx *reg_ctx = NULL;
    MPP_RET ret = MPP_OK;

    mpp_env_get_u32("hal_av1d_debug", &hal_av1d_debug, 0);

    INP_CHECK(ret, NULL == p_hal);

    p_hal->cfg = cfg;
    cfg->support_fast_mode = 1;
    p_hal->fast_mode = cfg->cfg->base.fast_parse && cfg->support_fast_mode;

    FUN_CHECK(hal_av1d_alloc_res(hal));

    mpp_slots_set_prop(cfg->frame_slots, SLOTS_HOR_ALIGN, mpp_align_128_odd_plus_64);
    mpp_slots_set_prop(cfg->frame_slots, SLOTS_VER_ALIGN, mpp_align_8);
    mpp_slots_set_prop(cfg->frame_slots, SLOTS_LEN_ALIGN, mpp_align_wxh2yuv422);

    if (cfg->hal_fbc_adj_cfg) {
        cfg->hal_fbc_adj_cfg->func = vdpu_afbc_align_calc;
        cfg->hal_fbc_adj_cfg->expand = 0;
    }

    reg_ctx = (Vdpu38xAv1dRegCtx *)p_hal->reg_ctx;
    vdpu38x_rcb_calc_init((Vdpu38xRcbCtx **)&reg_ctx->rcb_ctx);
    hal_dbg_init(&reg_ctx->dbg_ctx, "hal_av1d");
    if (p_hal->fast_mode && reg_ctx->dbg_ctx) {
        mpp_log("fast mode enabled, hal_dbg will be disabled");
        hal_dbg_deinit(&reg_ctx->dbg_ctx);
    }

__RETURN:
    return MPP_OK;
__FAILED:
    vdpu38x_av1d_deinit(hal);

    return ret;
}

static MPP_RET vdpu384b_av1d_rcb_calc(void *context, RK_U32 *total_size)
{
    Vdpu38xRcbCtx *ctx = (Vdpu38xRcbCtx *)context;
    RK_FLOAT cur_bit_size = 0;
    RK_U32 cur_uv_para = 0;
    RK_U32 bit_depth = ctx->bit_depth;
    RK_U32 in_tl_row = 0;
    RK_U32 on_tl_row = 0;
    RK_U32 on_tl_col = 0;
    Vdpu38xFmt rcb_fmt;

    /* vdpu383/vdpu384a/vdpu384b fix 10bit */
    bit_depth = 10;

    vdpu38x_rcb_get_len(ctx, VDPU38X_RCB_IN_TILE_ROW, &in_tl_row);
    vdpu38x_rcb_get_len(ctx, VDPU38X_RCB_ON_TILE_ROW, &on_tl_row);
    vdpu38x_rcb_get_len(ctx, VDPU38X_RCB_ON_TILE_COL, &on_tl_col);
    rcb_fmt = vdpu38x_rcb_get_fmt(ctx);

    /* RCB_STRMD_IN_ROW */
    cur_bit_size = 0;
    vdpu38x_rcb_reg_info_update(ctx, RCB_STRMD_IN_ROW, 140, cur_bit_size);

    /* RCB_STRMD_ON_ROW */
    cur_bit_size = 0;
    /*
     * For all spec, the hardware connects all in-tile rows of strmd to the on-tile.
     * Therefore, only strmd on-tile needs to be configured, and there is no need to
     * configure strmd in-tile.
     *
     * Versions with issues: swan1126b (384a), shark/robin (384b).
     */
    cur_bit_size = MPP_DIVUP(8, in_tl_row) * 100;
    vdpu38x_rcb_reg_info_update(ctx, RCB_STRMD_ON_ROW, 142, cur_bit_size);

    /* RCB_INTER_IN_ROW */
    cur_bit_size = 0;
    cur_bit_size = MPP_DIVUP(64, in_tl_row) * 2752;
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTER_IN_ROW, 144, cur_bit_size);

    /* RCB_INTER_ON_ROW */
    cur_bit_size = 0;
    cur_bit_size = MPP_DIVUP(64, on_tl_row) * 2752;
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTER_ON_ROW, 146, cur_bit_size);

    /* RCB_INTRA_IN_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_intra_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(512, (in_tl_row * (bit_depth + 2)
                                     * (1 + ctx->mbaff_flag) * cur_uv_para));
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTRA_IN_ROW, 148, cur_bit_size);

    /* RCB_INTRA_ON_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_intra_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(512, (on_tl_row * (bit_depth + 2)
                                     * (1 + ctx->mbaff_flag) * cur_uv_para));
    vdpu38x_rcb_reg_info_update(ctx, RCB_INTRA_ON_ROW, 150, cur_bit_size);

    /* RCB_FLTD_IN_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_filter_row_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(64, in_tl_row) * (1.2 * bit_depth + 0.5)
                   * (12.5 + 6 * cur_uv_para + 1.5 * ctx->lr_en);
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_IN_ROW, 152, cur_bit_size);

    /* RCB_FLTD_PROT_IN_ROW */
    cur_bit_size = 0;
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_PROT_IN_ROW,  154, cur_bit_size);

    /* RCB_FLTD_ON_ROW */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_filter_row_uv_coef_map[rcb_fmt];
    cur_bit_size = MPP_ROUNDUP(64, on_tl_row) * (1.2 * bit_depth + 0.5)
                   * (12.5 + 6 * cur_uv_para + 1.5 * ctx->lr_en);
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_ON_ROW, 156, cur_bit_size);

    /* RCB_FLTD_ON_COL */
    cur_bit_size = 0;
    cur_uv_para = vdpu38x_filter_col_uv_coef_map[rcb_fmt];
    if (ctx->tile_dir == 0)
        cur_bit_size = MPP_ROUNDUP(64, on_tl_col) * (1.6 * bit_depth + 0.5) *
                       (14 + 7 * cur_uv_para + (14 + 12.5 * cur_uv_para) * ctx->lr_en +
                        ( ctx->upsc_en ? (8.5 + 7 * cur_uv_para) : (5 + 1 * cur_uv_para)));
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_ON_COL, 158, cur_bit_size);

    /* RCB_FLTD_UPSC_ON_COL */
    cur_bit_size = 0;
    cur_bit_size = MPP_DIVUP(64, on_tl_col) * bit_depth * 22;
    vdpu38x_rcb_reg_info_update(ctx, RCB_FLTD_UPSC_ON_COL, 160, cur_bit_size);

    *total_size = vdpu38x_rcb_get_total_size(ctx);

    return MPP_OK;
}

MPP_RET vdpu384b_av1d_gen_regs(void *hal, HalTaskInfo *task)
{
    Av1dHalCtx *p_hal = (Av1dHalCtx *)hal;
    Vdpu38xAv1dRegCtx *ctx = (Vdpu38xAv1dRegCtx *)p_hal->reg_ctx;
    Vdpu38xRegSet *regs;
    DXVA_PicParams_AV1 *dxva = (DXVA_PicParams_AV1*)task->dec.syntax.data;
    HalBuf *origin_buf = NULL;
    MppFrame mframe;
    RK_U32 i = 0;
    MPP_RET ret = MPP_ERR_UNKNOW;
    MppHalCfg *cfg = p_hal->cfg;

    INP_CHECK(ret, NULL == p_hal);

    ctx->refresh_frame_flags = dxva->refresh_frame_flags;

    if (task->dec.flags.parse_err ||
        task->dec.flags.ref_err) {
        mpp_err_f("parse err %d ref err %d\n",
                  task->dec.flags.parse_err, task->dec.flags.ref_err);
        goto __RETURN;
    }

    mpp_buf_slot_get_prop(cfg->frame_slots, dxva->CurrPic.Index7Bits, SLOT_FRAME_PTR, &mframe);
    if (mpp_frame_get_thumbnail_en(mframe) == MPP_FRAME_THUMBNAIL_ONLY &&
        ctx->origin_bufs == NULL) {
        vdpu38x_setup_scale_origin_bufs(mframe, &ctx->origin_bufs,
                                        mpp_buf_slot_get_count(cfg->frame_slots));
    }

    if (p_hal->fast_mode) {
        for (i = 0; i <  MPP_ARRAY_ELEMS(ctx->reg_buf); i++) {
            if (!ctx->reg_buf[i].valid) {
                task->dec.reg_index = i;
                ctx->regs = ctx->reg_buf[i].regs;
                ctx->reg_buf[i].valid = 1;
                ctx->offset_uncomps = ctx->uncmps_offset[i];
                break;
            }
        }
    } else {
        task->dec.reg_index = 0;
    }
    regs = ctx->regs;
    memset(regs, 0, sizeof(*regs));
    p_hal->strm_len = (RK_S32)mpp_packet_get_length(task->dec.input_packet);

    hal_dbg_setup(ctx->dbg_ctx, NULL);

    vdpu38x_av1d_dbg_ref_frames(p_hal, dxva);

    vdpu384b_init_ctrl_regs(regs, MPP_VIDEO_CodingAV1);
    vdpu38x_setup_statistic(&regs->ctrl_regs);

    /* set reg -> pkt data */
    {
        MppBuffer mbuffer = NULL;

        /* uncompress header data */
        vdpu38x_av1d_uncomp_hdr(p_hal, dxva, (RK_U64 *)ctx->header_data, VDPU384B_UNCMPS_HEADER_SIZE / 8);
        memcpy((char *)ctx->bufs_ptr + ctx->offset_uncomps, (void *)ctx->header_data, VDPU384B_UNCMPS_HEADER_SIZE);
        regs->comm_paras.reg67_global_len = VDPU384B_UNCMPS_HEADER_SIZE / 16; // 128 bit as unit
        regs->comm_addrs.reg131_gbl_base = ctx->bufs_fd;
        mpp_dev_set_reg_offset(cfg->dev, 131, ctx->offset_uncomps);
        hal_dbg_dumpf_buf(ctx->dbg_ctx, "global_cfg.dat", ctx->bufs, ctx->offset_uncomps,
                          regs->comm_paras.reg67_global_len * 16, 128, "w+");
        // input strm
        p_hal->strm_len = (RK_S32)mpp_packet_get_length(task->dec.input_packet);
        regs->comm_paras.reg66_stream_len = MPP_ALIGN(p_hal->strm_len + 15, 128);
        mpp_buf_slot_get_prop(cfg->packet_slots, task->dec.input, SLOT_BUFFER, &mbuffer);
        regs->comm_addrs.reg128_strm_base = mpp_buffer_get_fd(mbuffer);
        regs->comm_addrs.reg129_stream_buf_st_base = mpp_buffer_get_fd(mbuffer);
        regs->comm_addrs.reg130_stream_buf_end_base = mpp_buffer_get_fd(mbuffer);
        mpp_dev_set_reg_offset(cfg->dev, 130, mpp_buffer_get_size(mbuffer));
        regs->comm_paras.reg65_strm_start_bit = 0; // bit start to decode
        /* error */
        regs->comm_addrs.reg169_error_ref_base = mpp_buffer_get_fd(mbuffer);
        hal_dbg_dumpf_buf(ctx->dbg_ctx, "stream_in.dat", mbuffer, 0,
                          p_hal->strm_len, 128, "w+");
    }

    vdpu38x_av1d_rcb_setup(p_hal, task, dxva, &regs->comm_addrs.rcb_regs,
                           vdpu384b_av1d_rcb_calc);

    /* set reg -> para (stride, len) */
    {
        MppFrameFormat fmt = 0;
        RK_U32 mapped_idx = 0;
        RK_U32 hor_virstride = 0;
        RK_U32 ver_virstride = 0;
        RK_U32 y_virstride = 0;
        RK_U32 fbc_head_stride = 0;
        RK_U32 fbc_pld_stride = 0;
        RK_U32 fbc_offset = 0;
        RK_U32 tile4x4_coeff = 0;

        if (vdpu38x_setup_cur_stride_info(mframe, regs, 1)) {
            mpp_err_f("failed to setup stride info for current frame\n");
            return MPP_NOK;
        }

        fmt = mpp_frame_get_fmt(mframe);
        for (i = 0; i < AV1_REFS_PER_FRAME; ++i) {
            mapped_idx = dxva->ref_frame_idx[i];
            if (dxva->frame_refs[mapped_idx].Index != (RK_S8)0xff && dxva->frame_refs[mapped_idx].Index != 0x7f) {
                mpp_buf_slot_get_prop(cfg->frame_slots, dxva->frame_refs[mapped_idx].Index, SLOT_FRAME_PTR, &mframe);
                if (mframe) {
                    hor_virstride = mpp_frame_get_hor_stride(mframe);
                    ver_virstride = mpp_frame_get_ver_stride(mframe);
                    y_virstride = hor_virstride * ver_virstride;
                    if (MPP_FRAME_FMT_IS_FBC(mpp_frame_get_fmt(mframe))) {
                        vdpu38x_get_fbc_off(mframe, &fbc_head_stride, &fbc_pld_stride, &fbc_offset);
                        regs->comm_paras.ref_stride[mapped_idx].hor_y_stride = fbc_head_stride;
                        regs->comm_paras.ref_stride[mapped_idx].hor_uv_stride = fbc_pld_stride;
                    } else if (MPP_FRAME_FMT_IS_TILE(mpp_frame_get_fmt(mframe))) {
                        if (vdpu38x_get_tile4x4_h_stride_coeff(fmt, &tile4x4_coeff)) {
                            mpp_err("get tile 4x4 coeff failed\n");
                            return MPP_NOK;
                        }
                        hor_virstride = MPP_ALIGN(hor_virstride * tile4x4_coeff, 16);
                        y_virstride += y_virstride / 2;
                        regs->comm_paras.ref_stride[mapped_idx].hor_y_stride = hor_virstride >> 4;
                        regs->comm_paras.ref_stride[mapped_idx].hor_uv_stride = hor_virstride >> 4;
                        regs->comm_paras.ref_stride[mapped_idx].y_stride = y_virstride >> 4;
                    } else {
                        regs->comm_paras.ref_stride[mapped_idx].hor_y_stride = hor_virstride >> 4;
                        regs->comm_paras.ref_stride[mapped_idx].hor_uv_stride = hor_virstride >> 4;
                        regs->comm_paras.ref_stride[mapped_idx].y_stride = y_virstride >> 4;
                    }
                }
            }
        }
    }

    /* set reg -> para (ref, fbc, colmv) */
    {
        MppBuffer mbuffer = NULL;
        RK_U32 mapped_idx;
        HalBuf *mv_buf = NULL;

        mpp_buf_slot_get_prop(cfg->frame_slots, task->dec.output, SLOT_FRAME_PTR, &mframe);
        mpp_buf_slot_get_prop(cfg->frame_slots, task->dec.output, SLOT_BUFFER, &mbuffer);
        regs->comm_addrs.reg168_decout_base = mpp_buffer_get_fd(mbuffer);
        regs->comm_addrs.reg192_payload_st_cur_base = mpp_buffer_get_fd(mbuffer);

        for (i = 0; i < AV1_REFS_PER_FRAME; i++) {
            mapped_idx = dxva->ref_frame_idx[i];
            if (dxva->frame_refs[mapped_idx].Index != (RK_S8)0xff && dxva->frame_refs[mapped_idx].Index != 0x7f) {
                mpp_buf_slot_get_prop(cfg->frame_slots, dxva->frame_refs[mapped_idx].Index, SLOT_BUFFER, &mbuffer);
                if (ctx->origin_bufs && mpp_frame_get_thumbnail_en(mframe) == MPP_FRAME_THUMBNAIL_ONLY) {
                    origin_buf = hal_bufs_get_buf(ctx->origin_bufs, dxva->frame_refs[mapped_idx].Index);
                    mbuffer = origin_buf->buf[0];
                }
                if (mbuffer) {
                    RK_U32 *reg_ref_base = NULL;
                    RK_U32 *reg_pld_base = NULL;

                    reg_ref_base = regs->comm_addrs.reg170_185_ref_base;
                    reg_ref_base[mapped_idx] = mpp_buffer_get_fd(mbuffer);
                    reg_pld_base = regs->comm_addrs.reg195_210_payload_st_ref_base;
                    reg_pld_base[mapped_idx] = mpp_buffer_get_fd(mbuffer);
                }
            }
        }

        vdpu38x_av1d_colmv_setup(p_hal, dxva);
        mv_buf = hal_bufs_get_buf(ctx->colmv_bufs, dxva->CurrPic.Index7Bits);
        regs->comm_addrs.reg216_colmv_cur_base = mpp_buffer_get_fd(mv_buf->buf[0]);
        for (i = 0; i < AV1_NUM_REF_FRAMES; i++) {
            if (dxva->frame_refs[i].Index != (RK_S8)0xff && dxva->frame_refs[i].Index != 0x7f) {
                mv_buf = hal_bufs_get_buf(ctx->colmv_bufs, dxva->frame_refs[i].Index);
                regs->comm_addrs.reg217_232_colmv_ref_base[i] = mpp_buffer_get_fd(mv_buf->buf[0]);
                hal_dbg_dumpf_buf(ctx->dbg_ctx, "colmv_ref_frame.dat", mv_buf->buf[0],
                                  0, ctx->colmv_size, 128, "w+");
            }
        }
    }

    vdpu38x_av1d_cdf_setup(p_hal, dxva);
    vdpu38x_av1d_set_cdf_segid(p_hal, dxva,
                               &regs->comm_addrs.reg178_av1_coef_rd_base,
                               &regs->comm_addrs.reg179_av1_coef_wr_base,
                               &regs->comm_addrs.reg181_av1_segid_last_base,
                               &regs->comm_addrs.reg182_av1_segid_cur_base,
                               &regs->comm_addrs.reg184_av1_noncoef_rd_base,
                               &regs->comm_addrs.reg185_av1_noncoef_wr_base);
    mpp_buffer_sync_end(ctx->bufs);

    {
        //scale down config
        MppBuffer mbuffer = NULL;
        RK_S32 fd = -1;
        MppFrameThumbnailMode thumbnail_mode;

        mpp_buf_slot_get_prop(cfg->frame_slots, dxva->CurrPic.Index7Bits, SLOT_BUFFER, &mbuffer);
        mpp_buf_slot_get_prop(cfg->frame_slots, dxva->CurrPic.Index7Bits,
                              SLOT_FRAME_PTR, &mframe);
        thumbnail_mode = mpp_frame_get_thumbnail_en(mframe);
        fd = mpp_buffer_get_fd(mbuffer);

        switch (thumbnail_mode) {
        case MPP_FRAME_THUMBNAIL_ONLY:
            regs->comm_addrs.reg133_scale_down_base = fd;
            origin_buf = hal_bufs_get_buf(ctx->origin_bufs, dxva->CurrPic.Index7Bits);
            fd = mpp_buffer_get_fd(origin_buf->buf[0]);
            regs->comm_addrs.reg168_decout_base = fd;
            regs->comm_addrs.reg192_payload_st_cur_base = fd;
            regs->comm_addrs.reg169_error_ref_base = fd;
            vdpu38x_setup_down_scale(mframe, cfg->dev, &regs->ctrl_regs,
                                     (void *)&regs->comm_paras);
            break;
        case MPP_FRAME_THUMBNAIL_MIXED:
            regs->comm_addrs.reg133_scale_down_base = fd;
            vdpu38x_setup_down_scale(mframe, cfg->dev, &regs->ctrl_regs,
                                     (void *)&regs->comm_paras);
            break;
        case MPP_FRAME_THUMBNAIL_NONE:
        default:
            regs->ctrl_regs.reg9.scale_down_en = 0;
            break;
        }
    }

__RETURN:
    return ret = MPP_OK;
}

MPP_RET vdpu384b_av1d_start(void *hal, HalTaskInfo *task)
{
    MPP_RET ret = MPP_ERR_UNKNOW;
    Av1dHalCtx *p_hal = (Av1dHalCtx *)hal;
    MppDev dev;

    INP_CHECK(ret, NULL == p_hal);
    if (task->dec.flags.parse_err ||
        task->dec.flags.ref_err) {
        goto __RETURN;
    }

    Vdpu38xAv1dRegCtx *reg_ctx = (Vdpu38xAv1dRegCtx *)p_hal->reg_ctx;
    Vdpu38xRegSet *regs = p_hal->fast_mode ?
                          reg_ctx->reg_buf[task->dec.reg_index].regs :
                          reg_ctx->regs;
    dev = p_hal->cfg->dev;
    do {
        MppDevRegWrCfg wr_cfg;
        MppDevRegRdCfg rd_cfg;

        wr_cfg.reg = &regs->ctrl_regs;
        wr_cfg.size = sizeof(regs->ctrl_regs);
        wr_cfg.offset = VDPU38X_OFF_CTRL_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_WR, &wr_cfg);
        if (ret) {
            mpp_err_f("set register write failed %d\n", ret);
            break;
        }

        wr_cfg.reg = &regs->comm_paras;
        wr_cfg.size = sizeof(regs->comm_paras);
        wr_cfg.offset = VDPU38X_OFF_CODEC_PARAS_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_WR, &wr_cfg);
        if (ret) {
            mpp_err_f("set register write failed %d\n", ret);
            break;
        }

        wr_cfg.reg = &regs->comm_addrs;
        wr_cfg.size = sizeof(regs->comm_addrs);
        wr_cfg.offset = VDPU38X_OFF_COMMON_ADDR_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_WR, &wr_cfg);
        if (ret) {
            mpp_err_f("set register write failed %d\n", ret);
            break;
        }

        rd_cfg.reg = &regs->ctrl_regs.reg15;
        rd_cfg.size = sizeof(regs->ctrl_regs.reg15);
        rd_cfg.offset = VDPU38X_OFF_INTERRUPT_REGS;
        ret = mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);
        if (ret) {
            mpp_err_f("set register read failed %d\n", ret);
            break;
        }

        vdpu38x_dump_sw_regs(regs, reg_ctx->dbg_ctx);

        ret = MPP_OK;
        if (hal_dbg_flag_en(reg_ctx->dbg_ctx, HAL_DBG_GET_REG)) {
            rd_cfg.reg = &regs->reg_version;
            rd_cfg.size = sizeof(regs->reg_version);
            rd_cfg.offset = 0;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->ctrl_regs;
            rd_cfg.size = sizeof(regs->ctrl_regs);
            rd_cfg.offset = VDPU38X_OFF_CTRL_REGS;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->comm_paras;
            rd_cfg.size = sizeof(regs->comm_paras);
            rd_cfg.offset = VDPU38X_OFF_CODEC_PARAS_REGS;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->comm_addrs;
            rd_cfg.size = sizeof(regs->comm_addrs);
            rd_cfg.offset = VDPU38X_OFF_COMMON_ADDR_REGS;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);

            rd_cfg.reg = &regs->statistic_regs;
            rd_cfg.size = sizeof(regs->statistic_regs);
            rd_cfg.offset = VDPU38X_OFF_COM_STATISTIC_REGS_VDPU384B;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);
        } else if (hal_dbg_flag_en(reg_ctx->dbg_ctx, HAL_DBG_STA_CHK)) {
            rd_cfg.reg = &regs->statistic_regs;
            rd_cfg.size = sizeof(regs->statistic_regs);
            rd_cfg.offset = VDPU38X_OFF_COM_STATISTIC_REGS_VDPU384B;
            ret |= mpp_dev_ioctl(dev, MPP_DEV_REG_RD, &rd_cfg);
        }
        if (ret) {
            mpp_err_f("set register read (debug) failed %d\n", ret);
        }

        /* rcb info for sram */
        vdpu38x_rcb_set_info(reg_ctx->rcb_ctx, dev);

        /* send request to hardware */
        ret = mpp_dev_ioctl(dev, MPP_DEV_CMD_SEND, NULL);
        if (ret) {
            mpp_err_f("send cmd failed %d\n", ret);
            break;
        }
    } while (0);

__RETURN:
    return ret = MPP_OK;
}

MPP_RET vdpu384b_av1d_wait(void *hal, HalTaskInfo *task)
{
    MPP_RET ret = MPP_ERR_UNKNOW;
    Av1dHalCtx *p_hal = (Av1dHalCtx *)hal;

    INP_CHECK(ret, NULL == p_hal);
    Vdpu38xAv1dRegCtx *reg_ctx = (Vdpu38xAv1dRegCtx *)p_hal->reg_ctx;
    Vdpu38xRegSet *p_regs = p_hal->fast_mode ?
                            reg_ctx->reg_buf[task->dec.reg_index].regs :
                            reg_ctx->regs;

    DXVA_PicParams_AV1 *dxva = (DXVA_PicParams_AV1*)task->dec.syntax.data;
    HalBuf *hal_buf_tmp = NULL;
    MppBuffer mbuffer = NULL;

    if (hal_dbg_flag_en(reg_ctx->dbg_ctx, HAL_DBG_DUMP) && 0 == p_hal->fast_mode) {
        hal_buf_tmp = hal_bufs_get_buf(reg_ctx->colmv_bufs, dxva->CurrPic.Index7Bits);
        hal_dbg_dumpf_buf(reg_ctx->dbg_ctx, "colmv_cur_frame.dat", hal_buf_tmp->buf[0],
                          0, reg_ctx->colmv_size, 128, "w+");
    }
    mpp_buf_slot_get_prop(p_hal->cfg->frame_slots, task->dec.output, SLOT_BUFFER, &mbuffer);
    hal_dbg_dumpf_buf(reg_ctx->dbg_ctx, "decout.dat", mbuffer, 0,
                      mpp_buffer_get_size(mbuffer), 128, "w+");

    if (task->dec.flags.parse_err ||
        task->dec.flags.ref_err) {
        goto __SKIP_HARD;
    }

    ret = mpp_dev_ioctl(p_hal->cfg->dev, MPP_DEV_CMD_POLL, NULL);
    if (ret)
        mpp_err_f("poll cmd failed %d\n", ret);

    if (hal_dbg_flag_en(reg_ctx->dbg_ctx, HAL_DBG_DUMP) && 0 == p_hal->fast_mode) {
        hal_buf_tmp = hal_bufs_get_buf(reg_ctx->cdf_segid_bufs, dxva->CurrPic.Index7Bits);
        hal_dbg_dumpf_buf(reg_ctx->dbg_ctx, "cabac_cdf_out.dat", hal_buf_tmp->buf[0],
                          0, NON_COEF_CDF_SIZE + COEF_CDF_SIZE, 128, "w+");
        hal_dbg_dumpf_buf(reg_ctx->dbg_ctx, "cabac_segid_out.dat", hal_buf_tmp->buf[0],
                          ALL_CDF_SIZE, reg_ctx->cdf_segid_size - ALL_CDF_SIZE, 128, "w+");
    }

    if (task->dec.flags.parse_err ||
        task->dec.flags.ref_err ||
        (!p_regs->ctrl_regs.reg15.rkvdec_frame_rdy_sta) ||
        p_regs->ctrl_regs.reg15.rkvdec_strm_error_sta ||
        p_regs->ctrl_regs.reg15.rkvdec_core_timeout_sta ||
        p_regs->ctrl_regs.reg15.rkvdec_ip_timeout_sta ||
        p_regs->ctrl_regs.reg15.rkvdec_bus_error_sta ||
        p_regs->ctrl_regs.reg15.rkvdec_buffer_empty_sta ||
        p_regs->ctrl_regs.reg15.rkvdec_colmv_ref_error_sta) {
        MppFrame mframe = NULL;

        mpp_buf_slot_get_prop(p_hal->cfg->frame_slots, task->dec.output, SLOT_FRAME_PTR, &mframe);
        mpp_frame_set_errinfo(mframe, 1);
    }

    if (hal_dbg_flag_en(reg_ctx->dbg_ctx, HAL_DBG_STA_CHK) &&
        (p_regs->statistic_regs.reg312.rcb_rd_sum_chk !=
         p_regs->statistic_regs.reg312.rcb_wr_sum_chk)) {
        mpp_loge("rcb rd sum %d wr sum %d\n",
                 p_regs->statistic_regs.reg312.rcb_rd_sum_chk,
                 p_regs->statistic_regs.reg312.rcb_wr_sum_chk);
    }

    if (hal_dbg_flag_en(reg_ctx->dbg_ctx, HAL_DBG_GET_REG))
        vdpu38x_dump_hw_regs(p_regs, reg_ctx->dbg_ctx);

__SKIP_HARD:
    if (p_hal->fast_mode)
        reg_ctx->reg_buf[task->dec.reg_index].valid = 0;

    hal_dbg_finish(reg_ctx->dbg_ctx);

__RETURN:
    return ret = MPP_OK;
}

const MppHalApi hal_av1d_vdpu384b = {
    .name       = "av1d_vdpu384b",
    .type       = MPP_CTX_DEC,
    .coding     = MPP_VIDEO_CodingAV1,
    .ctx_size   = sizeof(Av1dHalCtx),
    .flag       = 0,
    .init       = vdpu384b_av1d_init,
    .deinit     = vdpu38x_av1d_deinit,
    .reg_gen    = vdpu384b_av1d_gen_regs,
    .start      = vdpu384b_av1d_start,
    .wait       = vdpu384b_av1d_wait,
    .reset      = vdpu38x_av1d_reset,
    .flush      = vdpu38x_av1d_flush,
    .control    = vdpu38x_av1d_control,
    .client     = VPU_CLIENT_RKVDEC,
    .soc_type   = {
        ROCKCHIP_SOC_RK3572,
        ROCKCHIP_SOC_RK3538,
        ROCKCHIP_SOC_RK3539,
        ROCKCHIP_SOC_BUTT
    },
};

MPP_DEC_HAL_API_REGISTER(hal_av1d_vdpu384b)
