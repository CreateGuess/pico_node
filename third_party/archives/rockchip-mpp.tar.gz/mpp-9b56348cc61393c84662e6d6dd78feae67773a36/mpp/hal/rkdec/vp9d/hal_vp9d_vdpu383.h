/* SPDX-License-Identifier: Apache-2.0 OR MIT */
/*
 * Copyright (c) 2024 Rockchip Electronics Co., Ltd.
 */

#ifndef HAL_VP9D_VDPU383_H
#define HAL_VP9D_VDPU383_H

#include "mpp_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const MppHalApi hal_vp9d_vdpu383;

#ifdef __cplusplus
}
#endif
#endif /* HAL_VP9D_VDPU34X_H */
