/*
 * Copyright 2015 Rockchip Electronics Co. LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef PARSER_API_H
#define PARSER_API_H

#include "rk_mpi_cmd.h"
#include "mpp_packet.h"
#include "mpp_buf_slot.h"
#include "mpp_dec_cfg.h"
#include "hal_dec_task.h"
#include "mpp_soc.h"

/*
 * slots    - all decoder need a slots interface to sync its internal dpb management
 *            with buffer group in mpp_dec
 *
 * the reset wait for extension
 */
typedef struct DecParserInitCfg_t {
    MppCodingType       coding;
    MppBufSlots         frame_slots;
    MppBufSlots         packet_slots;
    MppDecCfgSet        *cfg;
    const MppDecHwCap   *hw_info;
} ParserCfg;


/*
 * Parser is the data structure provided from different decoders
 *
 * They will be static register to mpp_dec for scaning
 * name     - decoder name
 * coding   - decoder coding type
 * ctx_size - decoder context size, mpp_dec will use this to malloc memory
 * flag     - reserve
 *
 * init     - decoder initialization function
 * deinit   - decoder de-initialization function
 * parse    - decoder main working function, mpp_dec will input packet and get output syntax
 * reset    - decoder reset function
 * flush    - decoder output all frames
 * control  - decoder configure function
 */
typedef struct ParserApi_t {
    char            *name;
    MppCodingType   coding;
    RK_U32          ctx_size;
    RK_U32          flag;

    MPP_RET (*init)(void *ctx, ParserCfg *cfg);
    MPP_RET (*deinit)(void *ctx);

    MPP_RET (*prepare)(void *ctx, MppPacket pkt, HalDecTask *task);
    MPP_RET (*parse)(void *ctx, HalDecTask *task);

    MPP_RET (*reset)(void *ctx);
    MPP_RET (*flush)(void *ctx);
    MPP_RET (*control)(void *ctx, MpiCmd cmd, void *param);
    MPP_RET (*callback)(void *ctx, void *err_info);
    MPP_RET (*sync)(void *ctx, RK_S32 frame_id);
} ParserApi;


#endif /* PARSER_API_H */
