/*
 * Copyright 2021 Rockchip Electronics Co., Ltd
 *     Author: Jeffy Chen <jeffy.chen@rock-chips.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 */

#ifndef  __GST_MPP_H__
#define  __GST_MPP_H__

#include <drm_fourcc.h>

#include <gst/video/video.h>
#include <gst/allocators/gstdmabuf.h>

#ifndef AFBC_FORMAT_MOD_BLOCK_SIZE_16x16
#define AFBC_FORMAT_MOD_BLOCK_SIZE_16x16 (1ULL)
#endif

#ifndef AFBC_FORMAT_MOD_SPARSE
#define AFBC_FORMAT_MOD_SPARSE (((__u64)1) << 6)
#endif

/* The two AFBC geometries Rockchip decoders emit, as DRM modifiers.
 * The block size comes from MPP itself (mpp_frame_get_fmt_layout,
 * backed by the per-SoC capability table in osal/mpp_soc.c); the
 * SPARSE bit is proven on both SoCs (RK3588 emits 16x16|SPARSE,
 * RK3572 32x8|SPARSE).  MPP also reserves mpp_frame_get_fbc_sparse()
 * but nothing fills it today - when MPP wires it up the caller
 * should honor it instead of the constant. */
#define GST_MPP_AFBC_MODIFIER_16x16 \
  DRM_FORMAT_MOD_ARM_AFBC (AFBC_FORMAT_MOD_BLOCK_SIZE_16x16 | \
                           AFBC_FORMAT_MOD_SPARSE)
#define GST_MPP_AFBC_MODIFIER_32x8 \
  DRM_FORMAT_MOD_ARM_AFBC (AFBC_FORMAT_MOD_BLOCK_SIZE_32x8 | \
                           AFBC_FORMAT_MOD_SPARSE)

/* The modifier the Rockchip decoder and display drivers use for RFBC
 * buffers (vendor 64x4 block) */
#ifndef DRM_FORMAT_MOD_VENDOR_ROCKCHIP
#define DRM_FORMAT_MOD_VENDOR_ROCKCHIP 0x0b
#endif
#ifndef DRM_FORMAT_MOD_ROCKCHIP_TYPE_RFBC
#define DRM_FORMAT_MOD_ROCKCHIP_TYPE_RFBC 0x1
#endif
#ifndef ROCKCHIP_RFBC_BLOCK_SIZE_64x4
#define ROCKCHIP_RFBC_BLOCK_SIZE_64x4 (1ULL)
#endif
#ifndef DRM_FORMAT_MOD_ROCKCHIP_RFBC
#define DRM_FORMAT_MOD_ROCKCHIP_RFBC(mode) \
  ((((__u64) DRM_FORMAT_MOD_VENDOR_ROCKCHIP) << 56) | \
      (((__u64) DRM_FORMAT_MOD_ROCKCHIP_TYPE_RFBC) << 52) | \
      ((mode) & 0x000fffffffffffffULL))
#endif
#define GST_MPP_RFBC_MODIFIER \
  DRM_FORMAT_MOD_ROCKCHIP_RFBC(ROCKCHIP_RFBC_BLOCK_SIZE_64x4)

#ifdef HAVE_RGA
#include <rga/rga.h>
#include <rga/RgaApi.h>
#endif

#include <rockchip/rk_mpi.h>

static inline gboolean
gst_mpp_afbc_layout_to_modifier (guint layout, guint64 * modifier)
{
  switch (layout) {
    case MPP_FMT_AFBC16X16:
      *modifier = GST_MPP_AFBC_MODIFIER_16x16;
      return TRUE;
    case MPP_FMT_AFBC32X8:
      *modifier = GST_MPP_AFBC_MODIFIER_32x8;
      return TRUE;
    default:
      return FALSE;
  }
}

G_BEGIN_DECLS;

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(x) (sizeof(x)/sizeof(x[0]))
#endif

#ifndef SWAP
#define SWAP(x, y) ({ x ^= y; y ^= x; x ^= y; })
#endif

#define MPP_FMT_LE(f) (f | MPP_FRAME_FMT_LE_MASK)
#define MPP_FMT_RGB565LE MPP_FMT_LE(MPP_FMT_RGB565)
#define MPP_FMT_BGR565LE MPP_FMT_LE(MPP_FMT_BGR565)

#define GST_MPP_VIDEO_INFO_HSTRIDE(i) GST_VIDEO_INFO_PLANE_STRIDE(i, 0)
#define GST_MPP_VIDEO_INFO_VSTRIDE(i) \
    (GST_VIDEO_INFO_N_PLANES(i) == 1 ? GST_VIDEO_INFO_HEIGHT(i) : \
    (gint) (GST_VIDEO_INFO_PLANE_OFFSET(i, 1) / GST_MPP_VIDEO_INFO_HSTRIDE(i)))

#ifndef GST_VIDEO_FLAG_ARM_AFBC
#define GST_VIDEO_FLAG_ARM_AFBC (1UL << 31)
#define GST_VIDEO_INFO_SET_AFBC(i) \
  GST_VIDEO_INFO_FLAG_SET (i, GST_VIDEO_FLAG_ARM_AFBC)
#define GST_VIDEO_INFO_UNSET_AFBC(i) \
  GST_VIDEO_INFO_FLAG_UNSET (i, GST_VIDEO_FLAG_ARM_AFBC)
#define GST_VIDEO_INFO_IS_AFBC(i) \
  GST_VIDEO_INFO_FLAG_IS_SET (i, GST_VIDEO_FLAG_ARM_AFBC)
#endif

#ifndef GST_VIDEO_FLAG_RFBC
#define GST_VIDEO_FLAG_RFBC (1UL << 30)
#define GST_VIDEO_INFO_SET_RFBC(i) \
  GST_VIDEO_INFO_FLAG_SET (i, GST_VIDEO_FLAG_RFBC)
#define GST_VIDEO_INFO_UNSET_RFBC(i) \
  GST_VIDEO_INFO_FLAG_UNSET (i, GST_VIDEO_FLAG_RFBC)
#define GST_VIDEO_INFO_IS_RFBC(i) \
  GST_VIDEO_INFO_FLAG_IS_SET (i, GST_VIDEO_FLAG_RFBC)
#endif

/* The MPP requires alignment 16 by default */
#define GST_MPP_ALIGNMENT 16
#define GST_MPP_ALIGN(v) GST_ROUND_UP_N (v, GST_MPP_ALIGNMENT)

#ifdef HAVE_RGA
#define GST_RGA_FORMATS \
    "NV12, NV21, I420, YV12, NV16, NV61, " \
    "BGR16, RGB, BGR, RGBA, BGRA, RGBx, BGRx"
#endif

struct gst_mpp_format
{
  GstVideoFormat gst_format;
  MppFrameFormat mpp_format;
#ifdef HAVE_RGA
  RgaSURF_FORMAT rga_format;
#endif
  gint pixel_stride0;
  gboolean is_yuv;
};

extern struct gst_mpp_format gst_mpp_formats[];

/* Only the sentinel has both formats unset: rows for GstVideoFormats
 * this GStreamer lacks keep GST_VIDEO_FORMAT_UNKNOWN but still map an
 * MPP format, and must not end the scan. */
#define GST_MPP_FORMAT_IS_SENTINEL(f) \
  ((f)->gst_format == GST_VIDEO_FORMAT_UNKNOWN && \
      (f)->mpp_format == MPP_FMT_BUTT)

#define GST_MPP_GET_FORMAT(type, format) ({ \
  struct gst_mpp_format *_tmp = gst_mpp_formats; \
  for (; !GST_MPP_FORMAT_IS_SENTINEL (_tmp); _tmp++) { \
    if (_tmp->type ## _format == (format)) break;\
  }; \
  GST_MPP_FORMAT_IS_SENTINEL (_tmp) ? NULL : _tmp; \
})

gboolean gst_mpp_use_rga ();

const gchar *gst_mpp_video_format_to_string (GstVideoFormat format);

GstVideoFormat gst_mpp_mpp_format_to_gst_format (MppFrameFormat mpp_format);

MppFrameFormat gst_mpp_gst_format_to_mpp_format (GstVideoFormat format);

#ifdef HAVE_RGA
gboolean gst_mpp_rga_convert (GstBuffer * inbuf, GstVideoInfo * src_vinfo,
    GstMemory * out_mem, GstVideoInfo * dst_vinfo, gint rotation);

gboolean gst_mpp_rga_convert_from_mpp_frame (MppFrame mframe,
    GstMemory * out_mem, GstVideoInfo * dst_vinfo, gint rotation);

RgaSURF_FORMAT gst_mpp_mpp_format_to_rga_format (MppFrameFormat mpp_format);

RgaSURF_FORMAT gst_mpp_gst_format_to_rga_format (GstVideoFormat format);
#endif

gboolean gst_mpp_use_gpu (void);

/* Compression carried by a decoded frame */
gboolean gst_mpp_frame_is_fbc (MppFrame mframe);
gboolean gst_mpp_frame_is_rfbc (MppFrame mframe);
gboolean gst_mpp_frame_is_afbc (MppFrame mframe);

gboolean gst_mpp_gpu_convert_from_mpp_frame (MppFrame mframe,
    GstMemory * out_mem, GstVideoInfo * dst_vinfo, gint rotation,
    gboolean bt709, guint64 afbc_modifier);

/* TRUE when the GPU tier converts a compressed frame into that target */
gboolean gst_mpp_gpu_can_convert_compressed (GstVideoFormat dst_fmt);

/* Apply new format and size without reinit the video info */
void
gst_mpp_video_info_update_format (GstVideoInfo * info, GstVideoFormat format,
    guint width, guint height);

gboolean gst_mpp_video_info_align (GstVideoInfo * info,
    gint hstride, gint vstride);

gboolean gst_mpp_video_info_matched (GstVideoInfo * info, GstVideoInfo * other);

gboolean gst_mpp_frame_info_changed (MppFrame * frame, MppFrame * other);

guint gst_mpp_get_pixel_stride (GstVideoInfo * info);

G_END_DECLS;

#endif /* __GST_MPP_H__ */
