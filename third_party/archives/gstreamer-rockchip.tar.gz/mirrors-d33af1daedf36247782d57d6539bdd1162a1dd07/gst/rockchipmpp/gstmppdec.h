/*
 * Copyright 2021 Rockchip Electronics Co., Ltd
 *     Author: Jeffy Chen <jeffy.chen@rock-chips.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 */

#ifndef  __GST_MPP_DEC_H__
#define  __GST_MPP_DEC_H__

#include "gstmpp.h"

#include <gst/video/gstvideodecoder.h>

/* Give up on an MPP context that keeps rejecting input for this long.
 * A wedged decoder pipeline (e.g. an unparseable stream) never errors
 * out by itself; without a deadline the dataflow thread would block
 * in decode_put_packet() forever. */
#define GST_MPP_DEC_STALL_TIMEOUT_MS 2000

G_BEGIN_DECLS;

#define GST_TYPE_MPP_DEC	(gst_mpp_dec_get_type())
#define GST_MPP_DEC(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_MPP_DEC, GstMppDec))
#define GST_MPP_DEC_CLASS(klass) \
	(G_TYPE_CHECK_CLASS_CAST((klass), GST_TYPE_MPP_DEC, GstMppDecClass))
typedef struct _GstMppDec GstMppDec;
typedef struct _GstMppDecClass GstMppDecClass;

struct _GstMppDec
{
  GstVideoDecoder parent;

  GMutex mutex;
  GstAllocator *allocator;
  GstVideoCodecState *input_state;

  /* final output video info */
  GstVideoInfo info;

  /* decoded MPP frame info */
  MppFrame mpp_frame;

  /* specified output format */
  GstVideoFormat format;

  gboolean convert;
  gint rotation;
  gint width;
  gint height;

  guint crop_x, crop_y, crop_w, crop_h;

  gboolean fbc;

  /* AFBC data layout of the decoded output as reported by MPP
   * (MppFmtLayout; MPP_FMT_BUTT = not AFBC / not reported yet) */
  guint afbc_layout;

  /* DRM modifier derived from afbc_layout, carried to the GPU tier */
  guint64 neg_afbc_modifier;

  gboolean ignore_error;

  gboolean fast_mode;

  /* compression of current frame (cached from apply_info_change) */
  gboolean convert_afbc;
  gboolean convert_rfbc;

  /* stop handling new frame when flushing */
  gboolean flushing;

  /* drop frames when flushing but not draining */
  gboolean draining;

  /* flow return from pad task */
  GstFlowReturn task_ret;

  GstVideoInterlaceMode interlace_mode;

  /* seen valid PTS in input frames */
  gboolean seen_valid_pts;

  /* for using MPP generated PTS */
  gboolean use_mpp_pts;
  GstClockTime mpp_delta_pts;

  guint32 decoded_frames;

  GstVideoCodecFrame *last_frame;

  MppCodingType mpp_type;
  MppCtx mpp_ctx;
  MppApi *mpi;
};

struct _GstMppDecClass
{
  GstVideoDecoderClass parent_class;

    gboolean (*startup) (GstVideoDecoder * decoder);
    MppPacket (*get_mpp_packet) (GstVideoDecoder * decoder,
      GstMapInfo * mapinfo);
    gboolean (*shutdown) (GstVideoDecoder * decoder, gboolean drain);
};

G_DEFINE_AUTOPTR_CLEANUP_FUNC (GstMppDec, gst_object_unref);
GType gst_mpp_dec_get_type (void);

#define GST_FLOW_TIMEOUT GST_FLOW_CUSTOM_ERROR_1

#define MPP_DEC_OUT_FORMATS "NV12, NV16, NV12_10LE40, NV16_10LE40"

#ifdef HAVE_RGA
#define MPP_DEC_FORMATS MPP_DEC_OUT_FORMATS "," GST_RGA_FORMATS
#else
#define MPP_DEC_FORMATS MPP_DEC_OUT_FORMATS
#endif

#define MPP_DEC_CAPS_MAKE(fmts) \
    GST_VIDEO_CAPS_MAKE (fmts) ";" \
    GST_VIDEO_CAPS_MAKE_WITH_FEATURES (GST_CAPS_FEATURE_MEMORY_DMABUF, fmts)

/* Standard dma-drm form of the AFBC output.  The template lists both
 * plain geometries the Rockchip decoders emit (16x16|SPARSE on
 * RK3588 = 0x...41, 32x8|SPARSE on RK3572 = 0x...42); the actual
 * negotiated caps event carries the runtime value from
 * mpp_frame_get_fmt_layout() - the template only answers pad
 * queries and link-time intersections. */
#define MPP_DEC_CAPS_MAKE_DMA_DRM_AFBC \
    "video/x-raw(memory:DMABuf), format = (string) DMA_DRM, " \
    "drm-format = (string) { " \
    "YU08:0x0800000000000041, YU10:0x0800000000000041, " \
    "YUYV:0x0800000000000041, NV20:0x0800000000000041, " \
    "YU08:0x0800000000000042, YU10:0x0800000000000042, " \
    "YUYV:0x0800000000000042, NV20:0x0800000000000042 }, " \
    "width = (int) [ 1, MAX ], height = (int) [ 1, MAX ], " \
    "framerate = (fraction) [ 0/1, MAX ]"

/* RFBC keeps the plane's normal fourcc; the Rockchip modifier
 * describes the compression */
#define MPP_DEC_CAPS_MAKE_DMA_DRM_RFBC     "video/x-raw(memory:DMABuf), format = (string) DMA_DRM, "     "drm-format = (string) { "     "NV12:0x0b10000000000001, NV15:0x0b10000000000001, "     "NV16:0x0b10000000000001, NV20:0x0b10000000000001 }, "     "width = (int) [ 1, MAX ], height = (int) [ 1, MAX ], "     "framerate = (fraction) [ 0/1, MAX ]"

void gst_mpp_dec_fixup_video_info (GstVideoDecoder * decoder,
    GstVideoFormat format, gint width, gint height);

gboolean gst_mpp_dec_update_simple_video_info (GstVideoDecoder * decoder,
    GstVideoFormat format, guint width, guint height, guint align);

/* TRUE when a compressed (AFBC) frame can be converted by the GPU tier */
gboolean gst_mpp_dec_can_convert_afbc (GstMppDec * self);

G_END_DECLS;

#endif /* __GST_MPP_DEC_H__ */
